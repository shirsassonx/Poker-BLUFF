import { createFileRoute } from "@tanstack/react-router";
import type React from "react";
import { useEffect, useMemo, useRef, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "POKER BLUFF — Texas Hold’em MVP" },
      {
        name: "description",
        content: "A mobile-first neon Texas Hold’em poker game against a simple bot.",
      },
    ],
  }),
  component: PokerBluffGame,
});

type Suit = "♠" | "♥" | "♦" | "♣";
type Rank = "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10" | "J" | "Q" | "K" | "A";
type Card = { rank: Rank; suit: Suit; value: number; id: string };
type GameStatus = "idle" | "dealt" | "showdown" | "folded";
type Side = "you" | "bot" | "tie";
type BoundsKey = "bot" | "community" | "player";
type BoundsState = Record<BoundsKey, boolean>;

const suits: Suit[] = ["♠", "♥", "♦", "♣"];
const ranks: Rank[] = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
const previewCards: Card[] = [
  { rank: "K", suit: "♠", value: 13, id: "preview-ks" },
  { rank: "Q", suit: "♥", value: 12, id: "preview-qh" },
  { rank: "A", suit: "♦", value: 14, id: "preview-ad" },
  { rank: "10", suit: "♣", value: 10, id: "preview-10c" },
  { rank: "9", suit: "♥", value: 9, id: "preview-9h" },
  { rank: "6", suit: "♠", value: 6, id: "preview-6s" },
  { rank: "3", suit: "♦", value: 3, id: "preview-3d" },
  { rank: "J", suit: "♣", value: 11, id: "preview-jc" },
  { rank: "8", suit: "♥", value: 8, id: "preview-8h" },
];
const handNames = [
  "High card",
  "Pair",
  "Two pair",
  "Three of a kind",
  "Straight",
  "Flush",
  "Full house",
  "Four of a kind",
  "Straight flush",
];

function createDeck() {
  return suits.flatMap((suit) =>
    ranks.map((rank, index) => ({ rank, suit, value: index + 2, id: `${rank}${suit}` })),
  );
}

function shuffleDeck() {
  const deck = createDeck();
  for (let index = deck.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [deck[index], deck[swapIndex]] = [deck[swapIndex], deck[index]];
  }
  return deck;
}

function cardKey(card: Card) {
  return `${card.rank}${card.suit}`;
}

function rankLabel(value: number) {
  return ranks[value - 2];
}

function getStraightHigh(values: number[]) {
  const unique = [...new Set(values)].sort((a, b) => b - a);
  if (unique.includes(14)) unique.push(1);

  for (let index = 0; index <= unique.length - 5; index += 1) {
    const run = unique.slice(index, index + 5);
    if (run.every((value, runIndex) => runIndex === 0 || value === run[runIndex - 1] - 1)) {
      return run[0] === 1 ? 5 : run[0];
    }
  }
  return 0;
}

function compareNumbers(left: number[], right: number[]) {
  for (let index = 0; index < Math.max(left.length, right.length); index += 1) {
    const diff = (left[index] ?? 0) - (right[index] ?? 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

function evaluateHand(cards: Card[]) {
  const byValue = new Map<number, Card[]>();
  const bySuit = new Map<Suit, Card[]>();
  cards.forEach((card) => {
    byValue.set(card.value, [...(byValue.get(card.value) ?? []), card]);
    bySuit.set(card.suit, [...(bySuit.get(card.suit) ?? []), card]);
  });

  const values = [...byValue.keys()].sort((a, b) => b - a);
  const groups = [...byValue.entries()]
    .map(([value, group]) => ({ value, count: group.length, cards: group }))
    .sort((a, b) => b.count - a.count || b.value - a.value);
  const flushCards = [...bySuit.values()].find((group) => group.length >= 5)?.sort((a, b) => b.value - a.value);
  const straightHigh = getStraightHigh(cards.map((card) => card.value));
  const straightFlushHigh = flushCards ? getStraightHigh(flushCards.map((card) => card.value)) : 0;

  let score: number[];
  let nameIndex: number;
  let winningValues: number[];

  if (straightFlushHigh) {
    nameIndex = 8;
    score = [8, straightFlushHigh];
    winningValues = [straightFlushHigh, straightFlushHigh - 1, straightFlushHigh - 2, straightFlushHigh - 3, straightFlushHigh - 4].map((value) => value || 14);
  } else if (groups[0]?.count === 4) {
    nameIndex = 7;
    const kicker = values.find((value) => value !== groups[0].value) ?? 0;
    score = [7, groups[0].value, kicker];
    winningValues = [groups[0].value, kicker];
  } else if (groups[0]?.count === 3 && groups.some((group) => group.count >= 2 && group.value !== groups[0].value)) {
    nameIndex = 6;
    const pair = groups.find((group) => group.count >= 2 && group.value !== groups[0].value)?.value ?? 0;
    score = [6, groups[0].value, pair];
    winningValues = [groups[0].value, pair];
  } else if (flushCards) {
    nameIndex = 5;
    const topFlush = flushCards.slice(0, 5).map((card) => card.value);
    score = [5, ...topFlush];
    winningValues = topFlush;
  } else if (straightHigh) {
    nameIndex = 4;
    score = [4, straightHigh];
    winningValues = [straightHigh, straightHigh - 1, straightHigh - 2, straightHigh - 3, straightHigh - 4].map((value) => value || 14);
  } else if (groups[0]?.count === 3) {
    nameIndex = 3;
    const kickers = values.filter((value) => value !== groups[0].value).slice(0, 2);
    score = [3, groups[0].value, ...kickers];
    winningValues = [groups[0].value, ...kickers];
  } else if (groups.filter((group) => group.count === 2).length >= 2) {
    nameIndex = 2;
    const pairs = groups.filter((group) => group.count === 2).slice(0, 2).map((group) => group.value);
    const kicker = values.find((value) => !pairs.includes(value)) ?? 0;
    score = [2, ...pairs, kicker];
    winningValues = [...pairs, kicker];
  } else if (groups[0]?.count === 2) {
    nameIndex = 1;
    const kickers = values.filter((value) => value !== groups[0].value).slice(0, 3);
    score = [1, groups[0].value, ...kickers];
    winningValues = [groups[0].value, ...kickers];
  } else {
    nameIndex = 0;
    const highs = values.slice(0, 5);
    score = [0, ...highs];
    winningValues = highs;
  }

  const label = nameIndex === 1 ? `Pair of ${rankLabel(score[1])}s` : handNames[nameIndex];
  return { label, score, winningValues };
}

function getWinner(you: Card[], bot: Card[], community: Card[]) {
  const youHand = evaluateHand([...you, ...community]);
  const botHand = evaluateHand([...bot, ...community]);
  const comparison = compareNumbers(youHand.score, botHand.score);
  return {
    side: comparison > 0 ? "you" : comparison < 0 ? "bot" : ("tie" as Side),
    youHand,
    botHand,
  };
}

function PlayingCard({ card, highlight, dim }: { card: Card; highlight?: boolean; dim?: boolean }) {
  const isRed = card.suit === "♥" || card.suit === "♦";
  return (
    <div
      className={`deal-pop card-felt-shadow relative flex aspect-[5/7] min-w-0 flex-1 max-w-[2.48rem] flex-col justify-between overflow-hidden rounded-md border bg-card-face p-0.5 text-card-ink shadow-card transition duration-200 before:absolute before:inset-1 before:rounded-sm before:border before:border-card-ink/10 min-[390px]:max-w-[2.82rem] min-[430px]:max-w-[3.05rem] ${
        highlight ? "border-winner shadow-winner" : "border-border"
      } ${dim ? "brightness-90 saturate-75" : ""}`}
    >
      <div className={`relative z-10 flex flex-col items-start font-black leading-none ${isRed ? "text-card-red" : "text-card-ink"}`}>
        <span className="text-[0.68rem] min-[390px]:text-[0.78rem]">{card.rank}</span>
        <span className="text-[0.6rem] min-[390px]:text-[0.72rem]">{card.suit}</span>
      </div>
      <div className={`relative z-10 grid place-items-center text-2xl font-black leading-none min-[390px]:text-3xl ${isRed ? "text-card-red" : "text-card-ink"}`}>
        {card.suit}
      </div>
      <div className={`relative z-10 flex rotate-180 flex-col items-start font-black leading-none ${isRed ? "text-card-red" : "text-card-ink"}`}>
        <span className="text-[0.68rem] min-[390px]:text-[0.78rem]">{card.rank}</span>
        <span className="text-[0.6rem] min-[390px]:text-[0.72rem]">{card.suit}</span>
      </div>
    </div>
  );
}

function CardBack({ card = previewCards[0] }: { card?: Card }) {
  return <PlayingCard card={card} dim />;
}

function AvatarSeat({ name, side, active }: { name: string; side: "you" | "bot" | "guest"; active?: boolean }) {
  const face = side === "bot" ? "🤖" : side === "you" ? "👩🏻" : "🦝";
  return (
    <div className="flex flex-col items-center gap-0.5 text-center">
      <div className="rounded border border-border bg-background/80 px-2 py-0.5 text-[0.5rem] font-black text-muted-foreground">#13.2K</div>
      <div
        className={`relative grid size-10 place-items-center rounded-full border-2 bg-card text-xl shadow-neon min-[390px]:size-12 min-[390px]:text-2xl ${
          active ? "border-avatar-ring" : "border-border"
        }`}
      >
        {face}
        <span className="absolute -right-0.5 bottom-1 size-2.5 rounded-full bg-table-line shadow-cyan-neon" />
      </div>
      <div className="text-[0.56rem] font-black uppercase text-primary neon-title min-[390px]:text-[0.64rem]">{name}</div>
      <div className="rounded-md bg-background/90 px-2 py-0.5 text-[0.58rem] font-black text-foreground min-[390px]:text-[0.66rem]">🎲 1,980</div>
    </div>
  );
}

function StatPill({ label, value, icon }: { label: string; value: string | number; icon: string }) {
  return (
    <div className="flex min-w-0 items-center gap-1.5 rounded-lg border border-border bg-background/70 px-2 py-1.5 min-[390px]:gap-2 min-[390px]:px-3 min-[390px]:py-2">
      <span className="text-base min-[390px]:text-xl">{icon}</span>
      <div className="min-w-0">
        <p className="text-[0.5rem] font-black uppercase text-muted-foreground min-[390px]:text-[0.58rem]">{label}</p>
        <p className="truncate text-xs font-black text-foreground min-[390px]:text-base">{value}</p>
      </div>
    </div>
  );
}

function ActionButton({ tone, children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { tone: "fold" | "call" | "raise" | "deal" }) {
  const classes = {
    fold: "border-neon-red bg-destructive/30 text-neon-red shadow-red-neon",
    call: "border-glow-cyan bg-primary/25 text-glow-cyan shadow-cyan-neon",
    raise: "border-glow-purple bg-accent/30 text-glow-purple shadow-purple-neon",
    deal: "border-winner bg-winner/25 text-winner shadow-winner",
  }[tone];

  return (
    <button
      {...props}
      className={`h-12 rounded-lg border-2 px-1 text-[0.68rem] font-black uppercase leading-tight tracking-normal transition enabled:hover:scale-[1.02] disabled:brightness-75 min-[390px]:h-14 min-[390px]:text-sm ${classes} ${props.className ?? ""}`}
    >
      {children}
    </button>
  );
}

function BoundsBadge({ label, ok }: { label: string; ok: boolean }) {
  return (
    <div className={`rounded border px-1.5 py-0.5 text-[0.48rem] font-black uppercase leading-none min-[390px]:text-[0.54rem] ${ok ? "border-winner bg-winner/20 text-winner" : "border-destructive bg-destructive/25 text-neon-red"}`}>
      {label} {ok ? "✓" : "!"}
    </div>
  );
}

function PokerBluffGame() {
  const [playerCards, setPlayerCards] = useState<Card[]>([]);
  const [botCards, setBotCards] = useState<Card[]>([]);
  const [communityCards, setCommunityCards] = useState<Card[]>([]);
  const [status, setStatus] = useState<GameStatus>("idle");
  const [message, setMessage] = useState("Tap Deal to start a hand.");
  const [botMessage, setBotMessage] = useState("BOT waiting");
  const [pot, setPot] = useState(0);
  const tableRef = useRef<HTMLDivElement>(null);
  const botBoundsRef = useRef<HTMLDivElement>(null);
  const communityBoundsRef = useRef<HTMLDivElement>(null);
  const playerBoundsRef = useRef<HTMLDivElement>(null);
  const [boundsState, setBoundsState] = useState<BoundsState>({ bot: true, community: true, player: true });

  useEffect(() => {
    const checkBounds = () => {
      const table = tableRef.current?.getBoundingClientRect();
      if (!table) return;
      const refs = { bot: botBoundsRef, community: communityBoundsRef, player: playerBoundsRef };
      const next = Object.fromEntries(
        Object.entries(refs).map(([key, ref]) => {
          const bounds = ref.current?.getBoundingClientRect();
          const ok = Boolean(bounds && bounds.left >= table.left && bounds.right <= table.right && bounds.top >= table.top && bounds.bottom <= table.bottom);
          return [key, ok];
        }),
      ) as BoundsState;
      setBoundsState(next);
    };

    checkBounds();
    window.addEventListener("resize", checkBounds);
    return () => window.removeEventListener("resize", checkBounds);
  }, [botCards, communityCards, playerCards, status]);

  const result = useMemo(() => {
    if (status !== "showdown" || playerCards.length === 0) return null;
    return getWinner(playerCards, botCards, communityCards);
  }, [botCards, communityCards, playerCards, status]);

  const deal = () => {
    const deck = shuffleDeck();
    setPlayerCards(deck.slice(0, 2));
    setBotCards(deck.slice(2, 4));
    setCommunityCards(deck.slice(4, 9));
    setStatus("dealt");
    setPot(40);
    setMessage("Cards are out. Check, Call, Raise, or Fold.");
    setBotMessage("BOT checks");
  };

  const showdown = (action: "Check" | "Call" | "Raise") => {
    const botAction = action === "Raise" ? (Math.random() > 0.38 ? "BOT calls" : "BOT folds") : Math.random() > 0.25 ? "BOT checks" : "BOT calls";
    if (botAction === "BOT folds") {
      setStatus("showdown");
      setPot((current) => current + 30);
      setMessage("BOT folded. YOU win the pot.");
      setBotMessage(botAction);
      return;
    }
    setStatus("showdown");
    setPot((current) => current + (action === "Raise" ? 60 : action === "Call" ? 20 : 0));
    setMessage("Showdown. Best hand wins.");
    setBotMessage(botAction);
  };

  const fold = () => {
    if (status !== "dealt") return;
    setStatus("folded");
    setMessage("YOU folded. BOT wins this hand.");
    setBotMessage("BOT wins");
  };

  const youWinningValues = result?.side === "you" || result?.side === "tie" ? result.youHand.winningValues : [];
  const botWinningValues = result?.side === "bot" || result?.side === "tie" ? result.botHand.winningValues : [];
  const currentStage = status === "showdown" ? "SHOWDOWN" : status === "dealt" ? "YOUR TURN" : status === "folded" ? "FOLDED" : "READY";
  const playerHandLabel = result?.youHand.label ?? (status === "dealt" ? "Your turn" : "Deal cards");
  const botHandLabel = result?.botHand.label ?? botMessage;

  return (
    <main className="casino-floor min-h-[100svh] overflow-hidden px-2 py-2 text-foreground">
      <div className="mx-auto flex h-[calc(100svh-1rem)] max-w-[430px] flex-col gap-1">
        <header className="shrink-0 space-y-1">
          <div className="casino-panel rounded-lg border px-2.5 py-2">
            <div className="flex items-center justify-between gap-3">
              <button className="grid size-8 place-items-center rounded-lg border border-border bg-background/80 text-xl font-black text-foreground min-[390px]:size-10 min-[390px]:text-2xl" aria-label="Menu">
                ≡
              </button>
              <h1 className="pixel-neon-logo px-4 py-1 text-center text-xl font-black leading-none tracking-normal text-glow-cyan min-[390px]:px-6 min-[390px]:py-1.5 min-[390px]:text-2xl">
                POKER
                <span className="block text-glow-purple">BLUFF</span>
              </h1>
              <div className="rounded-lg border border-border bg-background/80 px-2 py-1.5 text-right min-[390px]:px-3 min-[390px]:py-2">
                <p className="text-xs font-black text-winner min-[390px]:text-sm">1,940</p>
              </div>
            </div>
          </div>
          <div className="casino-panel grid grid-cols-[1fr_1fr_1fr_auto] items-center gap-1 rounded-lg border px-2 py-1 min-[390px]:gap-2 min-[390px]:px-3 min-[390px]:py-1.5">
            <StatPill icon="🪙" label="Chips" value="1,940" />
            <StatPill icon="🎲" label="Pot" value={pot} />
            <StatPill icon="💎" label="Gems" value="0" />
            <button className="rounded-md border border-winner bg-background/70 px-2 py-2 text-[0.62rem] font-black uppercase text-winner">Showdown</button>
          </div>
        </header>

        <section className="relative flex min-h-0 flex-1 items-center justify-center py-0.5">
          <div ref={tableRef} className="table-aura relative flex h-full max-h-[60svh] min-h-[342px] w-full flex-col justify-between overflow-hidden rounded-[48%] border border-table-line bg-table-felt px-8 py-6 min-[390px]:min-h-[386px] min-[390px]:px-10 min-[390px]:py-7 min-[430px]:min-h-[412px]">
            <div className="pointer-events-none absolute inset-8 rounded-[48%] border border-table-line/45" />
            <div className="pointer-events-none absolute inset-13 rounded-[48%] border border-table-line/25" />
            <div className="pointer-events-none absolute inset-x-12 top-[57%] h-px bg-table-line/35" />
            <div className="absolute left-1/2 top-3 z-20 flex -translate-x-1/2 gap-1 rounded-md border border-border bg-background/80 px-1.5 py-1 shadow-neon">
              <BoundsBadge label="Bot" ok={boundsState.bot} />
              <BoundsBadge label="Board" ok={boundsState.community} />
              <BoundsBadge label="You" ok={boundsState.player} />
            </div>

            <div className="relative z-10 flex justify-center">
              <div className="flex flex-col items-center gap-0.5">
                <div className="rounded-md border border-glow-purple bg-background/85 px-3 py-0.5 text-[0.58rem] font-black uppercase text-glow-purple min-[390px]:text-[0.66rem]">BOT</div>
                <div className="scale-90 min-[390px]:scale-95"><AvatarSeat name="BOT" side="bot" active /></div>
                <div ref={botBoundsRef} className="flex w-[5.4rem] justify-center gap-1 min-[390px]:w-[6.15rem] min-[430px]:w-[6.55rem]">
                  {botCards.length ? (
                    botCards.map((card) => (
                      <PlayingCard key={cardKey(card)} card={card} highlight={botWinningValues.includes(card.value)} dim={Boolean(result && result.side === "you")} />
                    ))
                  ) : (
                    <>
                      <CardBack card={previewCards[0]} />
                      <CardBack card={previewCards[1]} />
                    </>
                  )}
                </div>
                <div className="max-w-28 truncate rounded bg-background/80 px-2 py-0.5 text-[0.54rem] font-black uppercase text-glow-purple min-[390px]:max-w-32 min-[390px]:text-[0.62rem]">{botHandLabel}</div>
              </div>
            </div>

            <div ref={communityBoundsRef} className="relative z-10 mx-auto w-full max-w-[14rem] space-y-1 text-center min-[390px]:max-w-[16rem] min-[390px]:space-y-1.5 min-[430px]:max-w-[17rem]">
              <div className="grid grid-cols-5 gap-0.5 min-[390px]:gap-1">
                {communityCards.length ? (
                  communityCards.map((card) => {
                    const highlighted = youWinningValues.includes(card.value) || botWinningValues.includes(card.value);
                    return <PlayingCard key={cardKey(card)} card={card} highlight={highlighted} dim={Boolean(result && !highlighted)} />;
                  })
                ) : (
                  previewCards.slice(2, 7).map((card) => <CardBack key={card.id} card={card} />)
                )}
              </div>
              <div className="mx-auto w-fit rounded-md bg-background/80 px-4 py-0.5 text-[0.64rem] font-black uppercase text-glow-cyan neon-title min-[390px]:py-1 min-[390px]:text-xs">{currentStage}</div>
            </div>

            <div className="relative z-10 flex items-end justify-center gap-1 min-[390px]:gap-1.5">
              <div className="scale-90 min-[390px]:scale-95"><AvatarSeat name="YOU" side="you" active={status === "dealt"} /></div>
              <div className="flex flex-col items-center gap-1">
                <div ref={playerBoundsRef} className="flex w-[5.4rem] justify-center gap-1 min-[390px]:w-[6.15rem] min-[430px]:w-[6.55rem]">
                  {playerCards.length ? (
                    playerCards.map((card) => (
                      <PlayingCard key={cardKey(card)} card={card} highlight={youWinningValues.includes(card.value)} dim={Boolean(result && result.side === "bot")} />
                    ))
                  ) : (
                    <>
                      <CardBack card={previewCards[7]} />
                      <CardBack card={previewCards[8]} />
                    </>
                  )}
                </div>
                <div className="max-w-44 truncate rounded bg-background/85 px-3 py-0.5 text-[0.6rem] font-black uppercase text-glow-cyan min-[390px]:text-[0.7rem]">YOU · {playerHandLabel}</div>
              </div>
            </div>
          </div>
        </section>

        <section className="shrink-0 space-y-1 pb-[env(safe-area-inset-bottom)]">
          {result && (
            <div className="showdown-panel rounded-lg border p-2 text-center min-[390px]:p-3">
              <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 min-[390px]:gap-3">
                <div>
                  <p className="text-xs font-black text-glow-cyan">YOU</p>
                  <div className="mt-2 flex justify-center gap-1.5">{playerCards.map((card) => <PlayingCard key={cardKey(card)} card={card} highlight={youWinningValues.includes(card.value)} />)}</div>
                  <p className="mt-2 text-[0.72rem] font-black uppercase text-glow-cyan">{result.youHand.label}</p>
                </div>
                <p className="text-2xl font-black text-muted-foreground">VS</p>
                <div>
                  <p className="text-xs font-black text-glow-purple">BOT</p>
                  <div className="mt-2 flex justify-center gap-1.5">{botCards.map((card) => <PlayingCard key={cardKey(card)} card={card} highlight={botWinningValues.includes(card.value)} />)}</div>
                  <p className="mt-2 text-[0.72rem] font-black uppercase text-glow-purple">{result.botHand.label}</p>
                </div>
              </div>
              <p className="mt-2 text-lg font-black uppercase text-glow-cyan neon-title min-[390px]:mt-3 min-[390px]:text-xl">{result.side === "you" ? "✦ YOU WIN! ✦" : result.side === "bot" ? "BOT WINS" : "PUSH"}</p>
            </div>
          )}

          <div className="grid grid-cols-[1fr_1fr_1fr_0.58fr] gap-1 min-[390px]:gap-2">
            <ActionButton tone="fold" disabled={status !== "dealt"} onClick={fold}>✕ Fold</ActionButton>
            <ActionButton tone="call" disabled={status !== "dealt"} onClick={() => showdown(status === "dealt" ? "Call" : "Check")}>🪙 {status === "dealt" ? "Call" : "Check"}</ActionButton>
            <ActionButton tone="raise" disabled={status !== "dealt"} onClick={() => showdown("Raise")}>↑ Raise</ActionButton>
            <ActionButton tone="deal" onClick={deal} className="text-xs">Deal</ActionButton>
          </div>
          <div className="casino-panel grid grid-cols-[auto_1fr_auto] items-center gap-3 rounded-lg border px-3 py-1.5 min-[390px]:py-2">
            <button className="grid size-8 place-items-center rounded-md border border-border bg-background/60 text-lg font-black text-muted-foreground min-[390px]:size-9">−</button>
            <div className="h-2 rounded-full bg-muted"><div className="h-full w-1/4 rounded-full bg-glow-purple shadow-purple-neon" /></div>
            <button className="grid size-8 place-items-center rounded-md border border-border bg-background/60 text-lg font-black text-glow-purple min-[390px]:size-9">+</button>
          </div>
        </section>
      </div>
    </main>
  );
}